﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebTokenAula1.Models
{
    [Table("Token")]
    public class Token
    {
        [Column("ID")]
        public int Id { get; set; }

        [Column("MENSAGEMTOKEN")]
        public string MensagemToken { get; set; }

        [Column("DATAVALIDA")]
        public DateTime DataValida { get; set; }

        [ForeignKey("Usuario")]
        [Column(Order = 1)]
        public int USUARIO_ID { get; set; }
        public virtual Usuario Usuario { get; set; }

    }
}
