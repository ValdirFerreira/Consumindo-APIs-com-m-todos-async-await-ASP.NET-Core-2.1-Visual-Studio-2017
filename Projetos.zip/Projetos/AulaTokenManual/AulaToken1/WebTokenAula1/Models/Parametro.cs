﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebTokenAula1.Models
{
    public class Parametro
    {
        public string email { get; set; }
        public string senha { get; set; }
        public string token { get; set; }
    }
}
