﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebTokenAula1.Models;

namespace WebTokenAula1.Controllers
{
    public class HomeController : Controller
    {
        private readonly Contexto contexto;

        public HomeController(Contexto _contexto)
        {
            contexto = _contexto;
        }

        public IActionResult Index()
        {
            if (contexto.Usuario.Where(u => u.Email == "valdir@valdir.com").FirstOrDefault() == null)
            {
                contexto.Usuario.Add(new Usuario { Email = "valdir@valdir.com", Senha = "1234" });
                contexto.SaveChanges();
            }

            return View();
        }

        [HttpPost("/api/GerarToken")]
        public JsonResult GerarToken([FromBody] Parametro parametro)
        {
            var usuarioBanco = contexto.Usuario.Where(u => u.Email == parametro.email && u.Senha == parametro.senha).FirstOrDefault();

            if (usuarioBanco != null)
            {
                return Json(new { token = GeraValorToken(usuarioBanco.Id) });
            }
            else
            {
                return Json(new { token = string.Empty });
            }
        }

        [HttpPost("/api/ValidarToken")]
        public JsonResult ValidarToken([FromBody] Parametro parametro)
        {
            return Json(new { token = VerificaToken(parametro) });
        }

        // Novo Metodo
        [HttpPost("api/ListarProdutos")]
        public JsonResult ListarProdutos([FromBody]Parametro parametro)
        {

            var lista = new List<Produto>();

            var retorno = VerificaToken(parametro);


            if (string.IsNullOrWhiteSpace(retorno.ToString()))
                return Json(lista);


            for (int i = 1; i <= 10; i++)
            {
                lista.Add(new Produto { Id = i, NomeProduto = "Nome produto - " + i.ToString() });
            }

            return Json(lista);
        }

        // Novo Metodo
        public string VerificaToken(Parametro parametro)
        {
            var tokenExiste = contexto.Token.Where(t => t.MensagemToken == parametro.token).FirstOrDefault();

            if (tokenExiste != null)
            {

                var data1 = DateTime.Now;
                var data2 = tokenExiste.DataValida;

                TimeSpan tempo = data1 - data2;

                if (tempo.Minutes > 30)
                {
                    return string.Empty;
                }
                else
                {
                    return tokenExiste.MensagemToken;
                }
            }
            else
            {
                return string.Empty;
            }
        }

        private string GeraValorToken(int idUsuario)
        {
            var tokenExistente = contexto.Token.Where(t => t.USUARIO_ID == idUsuario).ToList();

            if (tokenExistente.Count > 0)
            {
                contexto.Token.RemoveRange(tokenExistente);
                contexto.SaveChanges();
            }

            var dataValida = DateTime.Now;

            var token = string.Concat(Guid.NewGuid().ToString(), dataValida.Day.ToString(),
                dataValida.Month.ToString(), dataValida.Year.ToString());


            var meuToken = new Token
            {
                DataValida = dataValida,
                MensagemToken = token,
                USUARIO_ID = idUsuario
            };



            try
            {
                contexto.Token.Add(meuToken);
                contexto.SaveChanges();
            }
            catch (Exception)
            {
                return string.Empty;
            }

            return meuToken.MensagemToken;

        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
