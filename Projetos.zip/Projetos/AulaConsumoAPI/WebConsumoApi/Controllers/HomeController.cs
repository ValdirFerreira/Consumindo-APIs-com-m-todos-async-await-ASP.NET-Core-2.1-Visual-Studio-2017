﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebConsumoApi.Models;

namespace WebConsumoApi.Controllers
{
    public class HomeController : Controller
    {

        private string _token { get; set; }

        private List<Produto> ListaProduto { get; set; }


        public IActionResult Index()
        {

            //Task Tarefa1 = GetToken();
            //Tarefa1.Wait();

            //Task Tarefa2 = GetProduto(_token);
            //Tarefa2.Wait();



            Task Manual1 = GetTokenManual();
            Manual1.Wait();

            Task Manual2 = GetProdutomanual(_token);
            Manual2.Wait();

            return View(ListaProduto);
        }


        #region METODOS PARA CONSUMO JWT
        private async Task GetToken()
        {
            string url = "http://localhost:50094/api/CreateToken";

            using (var cliente = new HttpClient())
            {

                string JsonObjeto = JsonConvert.SerializeObject(new Usuario { name = "valdir", password = "1234" });

                var content = new StringContent(JsonObjeto, Encoding.UTF8, "application/json");

                var resuldado = cliente.PostAsync(url, content).Result;

                if (resuldado.IsSuccessStatusCode)
                {
                    var tokenJson = await resuldado.Content.ReadAsStringAsync();

                    _token = JsonConvert.DeserializeObject(tokenJson).ToString();
                }

            }

        }

        private async Task GetProduto(string tokenAcess)
        {


            using (var client = new HttpClient())
            {
                var url = "http://localhost:50094/api/ListarProdutos";
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + tokenAcess);
                var response = await client.GetStringAsync(url);

                var listaRetorno = JsonConvert.DeserializeObject<Produto[]>(response).ToList();

                ListaProduto = listaRetorno;
            }


        }
        #endregion


        #region Metodos utilizados na geração manual de token
        private async Task GetTokenManual()
        {
            string url = "http://localhost:51039/api/GerarToken";

            using (var cliente = new HttpClient())
            {

                string JsonObjeto = JsonConvert.SerializeObject(new Parametro { email = "valdir@valdir.com", senha = "1234" });

                var content = new StringContent(JsonObjeto, Encoding.UTF8, "application/json");

                var resuldado = cliente.PostAsync(url, content).Result;

                if (resuldado.IsSuccessStatusCode)
                {
                    var tokenJson = await resuldado.Content.ReadAsStringAsync();

                    var objToken = JsonConvert.DeserializeObject<ObjetoToken>(tokenJson);

                    _token = objToken.token;

                }

            }

        }




        private async Task GetProdutomanual(string tokenAcess)
        {
            string url = "http://localhost:51039/api/ListarProdutos";

            using (var cliente = new HttpClient())
            {

                string jsonToken = JsonConvert.SerializeObject(new Parametro { token = tokenAcess });

                var content = new StringContent(jsonToken, Encoding.UTF8, "application/json");

                var resuldado = cliente.PostAsync(url, content).Result;

                if (resuldado.IsSuccessStatusCode)
                {
                    var produtosJson = await resuldado.Content.ReadAsStringAsync();

                    var ObjetoProdutos = JsonConvert.DeserializeObject<Produto[]>(produtosJson).ToList();

                    ListaProduto = ObjetoProdutos;

                }

            }

        }

        #endregion





        #region  OLD
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #endregion
    }
}
